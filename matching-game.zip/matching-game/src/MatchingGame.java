/*
 * A game of matching pairs of cards together
 * 
 * modified		20210410
 * date			20210406
 * @filename	MatchingGame.java
 * @author		Alvin Chan
 * @version		1.0
 * @see			ICS4U Content
 */

import java.util.*;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.GroupLayout.Alignment;
import javax.swing.GroupLayout;
import javax.swing.LayoutStyle.ComponentPlacement;
import java.awt.GridLayout;
import javax.swing.JLabel;

public class MatchingGame extends javax.swing.JFrame {
	ArrayList<String> cards = new ArrayList<String>();
	ArrayList<String> set = new ArrayList<String>();
	ImageIcon wPawn = new ImageIcon("whitepawn.png");
	ImageIcon wKnight = new ImageIcon("whiteknight.png");
	ImageIcon wBishop = new ImageIcon("whitebishop.png");
	ImageIcon wRook = new ImageIcon("whiterook.png");
	ImageIcon wQueen = new ImageIcon("whitequeen.png");
	ImageIcon wKing = new ImageIcon("whiteking.png");
	ImageIcon bPawn = new ImageIcon("blackpawn.png");
	ImageIcon bKnight = new ImageIcon("blackknight.png");
	ImageIcon bBishop = new ImageIcon("blackbishop.png");
	ImageIcon bRook = new ImageIcon("blackrook.png");
	ImageIcon bQueen = new ImageIcon("blackqueen.png");
	ImageIcon bKing = new ImageIcon("blackking.png");
	ImageIcon back = new ImageIcon("cardback.jpg");
	ImageIcon done = new ImageIcon("done.jpg");
	int count, c1, c2, card1, card2;
	int cardsLeft = 24 - 2; // value 2 lower to realign in the end
	int[] change = new int[24];
	int guesses = 2;
	boolean running = false;
	// initializing arrays of booleans corresponding to each card
	boolean[] guessed = { false, false, false, false, false, false, false, false, false, false, false, false, false,
			false, false, false, false, false, false, false, false, false, false, false };
	boolean[] matched = { false, false, false, false, false, false, false, false, false, false, false, false, false,
			false, false, false, false, false, false, false, false, false, false, false };

	/**
	 * Creates new form MatchingGame
	 */
	public MatchingGame() {
		initComponents();
		btnPlayActionPerformed();
	}

	@SuppressWarnings("unchecked")
	private void initComponents() {
		mainTitle = new javax.swing.JLabel();
		Card1 = new javax.swing.JButton();
		Card2 = new javax.swing.JButton();
		Card3 = new javax.swing.JButton();
		Card4 = new javax.swing.JButton();
		Card17 = new JButton();
		Card18 = new JButton();
		Card19 = new JButton();
		Card20 = new JButton();
		Card21 = new JButton();
		Card22 = new JButton();
		Card23 = new JButton();
		Card24 = new JButton();
		txtInstruction = new javax.swing.JTextField();

		setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
		setTitle("Matching Game");

		mainTitle.setFont(new java.awt.Font("Tahoma", 0, 24));
		mainTitle.setForeground(new java.awt.Color(255, 0, 0));
		mainTitle.setText("Matching Game");

		Card1.setIcon(back);
		Card1.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				Card1ActionPerformed(evt);
			}
		});

		Card2.setIcon(back); 
		Card2.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				Card2ActionPerformed(evt);
			}
		});

		Card3.setIcon(back); 
		Card3.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				Card3ActionPerformed(evt);
			}
		});

		Card4.setIcon(back); 
		Card4.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				Card4ActionPerformed(evt);
			}
		});

		Card17.setIcon(back); 
		Card17.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				Card17ActionPerformed(evt);
			}
		});

		Card18.setIcon(back);
		Card18.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				Card18ActionPerformed(evt);
			}
		});

		Card19.setIcon(back); 
		Card19.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				Card19ActionPerformed(evt);
			}
		});

		Card20.setIcon(back); 
		Card20.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				Card20ActionPerformed(evt);
			}
		});

		Card21.setIcon(back); 
		Card21.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				Card21ActionPerformed(evt);
			}
		});

		Card22.setIcon(back);
		Card22.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				Card22ActionPerformed(evt);
			}
		});

		Card23.setIcon(back);
		Card23.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				Card23ActionPerformed(evt);
			}
		});

		Card24.setIcon(back); 
		Card24.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				Card24ActionPerformed(evt);
			}
		});
		getContentPane().setLayout(new GridLayout(0, 6, 0, 0));
		
		label = new JLabel("");
		getContentPane().add(label);
		
		label_1 = new JLabel("");
		getContentPane().add(label_1);
		getContentPane().add(mainTitle);
		
		label_2 = new JLabel("");
		getContentPane().add(label_2);
		
		label_3 = new JLabel("");
		getContentPane().add(label_3);
		
		label_4 = new JLabel("");
		getContentPane().add(label_4);
		getContentPane().add(Card1);
		getContentPane().add(Card2);
		getContentPane().add(Card3);
		getContentPane().add(Card4);
		getContentPane().add(Card17);
		getContentPane().add(Card21);
		Card8 = new javax.swing.JButton();
		
				Card8.setIcon(back); // NOI18N
				Card8.addActionListener(new java.awt.event.ActionListener() {
					public void actionPerformed(java.awt.event.ActionEvent evt) {
						Card8ActionPerformed(evt);
					}
				});
				Card7 = new javax.swing.JButton();
				
						Card7.setIcon(back); // NOI18N
						Card7.addActionListener(new java.awt.event.ActionListener() {
							public void actionPerformed(java.awt.event.ActionEvent evt) {
								Card7ActionPerformed(evt);
							}
						});
						Card6 = new javax.swing.JButton();
						
								Card6.setIcon(back); // NOI18N
								Card6.addActionListener(new java.awt.event.ActionListener() {
									public void actionPerformed(java.awt.event.ActionEvent evt) {
										Card6ActionPerformed(evt);
									}
								});
								Card5 = new javax.swing.JButton();
								
										Card5.setIcon(back); // NOI18N
										Card5.addActionListener(new java.awt.event.ActionListener() {
											public void actionPerformed(java.awt.event.ActionEvent evt) {
												Card5ActionPerformed(evt);
											}
										});
										getContentPane().add(Card5);
								getContentPane().add(Card6);
						getContentPane().add(Card7);
				getContentPane().add(Card8);
		getContentPane().add(Card18);
		getContentPane().add(Card22);
		Card12 = new javax.swing.JButton();
		
				Card12.setIcon(back); // NOI18N
				Card12.addActionListener(new java.awt.event.ActionListener() {
					public void actionPerformed(java.awt.event.ActionEvent evt) {
						Card12ActionPerformed(evt);
					}
				});
				Card11 = new javax.swing.JButton();
				
						Card11.setIcon(back); // NOI18N
						Card11.addActionListener(new java.awt.event.ActionListener() {
							public void actionPerformed(java.awt.event.ActionEvent evt) {
								Card11ActionPerformed(evt);
							}
						});
						Card10 = new javax.swing.JButton();
						
								Card10.setIcon(back); // NOI18N
								Card10.addActionListener(new java.awt.event.ActionListener() {
									public void actionPerformed(java.awt.event.ActionEvent evt) {
										Card10ActionPerformed(evt);
									}
								});
								Card9 = new javax.swing.JButton();
								
										Card9.setIcon(back); // NOI18N
										Card9.addActionListener(new java.awt.event.ActionListener() {
											public void actionPerformed(java.awt.event.ActionEvent evt) {
												Card9ActionPerformed(evt);
											}
										});
										getContentPane().add(Card9);
								getContentPane().add(Card10);
						getContentPane().add(Card11);
				getContentPane().add(Card12);
		getContentPane().add(Card19);
		getContentPane().add(Card23);
		Card16 = new javax.swing.JButton();
		
				Card16.setIcon(back); // NOI18N
				Card16.addActionListener(new java.awt.event.ActionListener() {
					public void actionPerformed(java.awt.event.ActionEvent evt) {
						Card16ActionPerformed(evt);
					}
				});
				Card15 = new javax.swing.JButton();
				
						Card15.setIcon(back); // NOI18N
						Card15.addActionListener(new java.awt.event.ActionListener() {
							public void actionPerformed(java.awt.event.ActionEvent evt) {
								Card15ActionPerformed(evt);
							}
						});
						Card14 = new javax.swing.JButton();
						
								Card14.setIcon(back); // NOI18N
								Card14.addActionListener(new java.awt.event.ActionListener() {
									public void actionPerformed(java.awt.event.ActionEvent evt) {
										Card14ActionPerformed(evt);
									}
								});
								Card13 = new javax.swing.JButton();
								
										Card13.setIcon(back); // NOI18N
										Card13.addActionListener(new java.awt.event.ActionListener() {
											public void actionPerformed(java.awt.event.ActionEvent evt) {
												Card13ActionPerformed(evt);
											}
										});
										getContentPane().add(Card13);
								getContentPane().add(Card14);
						getContentPane().add(Card15);
				getContentPane().add(Card16);
		getContentPane().add(Card20);
		getContentPane().add(Card24);
		getContentPane().add(txtInstruction);
		
		label_5 = new JLabel("");
		getContentPane().add(label_5);
		
		label_6 = new JLabel("");
		getContentPane().add(label_6);
		
		label_7 = new JLabel("");
		getContentPane().add(label_7);
		
		label_8 = new JLabel("");
		getContentPane().add(label_8);
		
		label_9 = new JLabel("");
		getContentPane().add(label_9);

		pack();
	}

	private void btnPlayActionPerformed() {
		running = true;

		// setting change array
		for (int z = 0; z <= 23; z++) { 
			change[z] = 1;
		}

		// assigns random cards
		String temp;
		for (int x = 0; x <= 11; x++) { 
			for (int y = 1; y <= 2; y++) {
				temp = Integer.toString(x);
				set.add(temp);
			}
		}

		for (int x = 0; x <= 23; x++) { 
			double index = Math.floor(Math.random() * (24 - x)); 
			int index1 = (int) index;
			cards.add(set.get(index1));
			set.remove(set.get(index1));
		}
	}

	private void cardClicked(JButton card) {
		JButton[] cardsList = { Card1, Card2, Card3, Card4, Card5, Card6, Card7, Card8, Card9, Card10, Card11, Card12,
				Card13, Card14, Card15, Card16, Card17, Card18, Card19, Card20, Card21, Card22, Card23, Card24 };
		int index = 0;

		// determining which index to use
		for (int i = 0; i < cardsList.length; i++) {
			if (card == cardsList[i]) {
				index = i;
			}
		}

		if (guesses == 0) {
			btuGuessAgainActionPerformed();
		}
		
		// card selection
		if (guesses > 0 && guessed[index] == false && running == true && matched[index] == false) {
			String temp = cards.get(index);

			if (temp.equals("0")) {
				card.setIcon(wPawn);
			} else if (temp.equals("1")) {
				card.setIcon(wKnight);
			} else if (temp.equals("2")) {
				card.setIcon(wBishop);
			} else if (temp.equals("3")) {
				card.setIcon(wRook);
			} else if (temp.equals("4")) {
				card.setIcon(wQueen);
			} else if (temp.equals("5")) {
				card.setIcon(wKing);
			} else if (temp.equals("6")) {
				card.setIcon(bPawn);
			} else if (temp.equals("7")) {
				card.setIcon(bKnight);
			} else if (temp.equals("8")) {
				card.setIcon(bBishop);
			} else if (temp.equals("9")) {
				card.setIcon(bRook);
			} else if (temp.equals("10")) {
				card.setIcon(bQueen);
			} else if (temp.equals("11")) {
				card.setIcon(bKing);
			}

			count++;
			if (count == 1) {
				c1 = Integer.parseInt(temp);
				change[index] = 0;
			} else if (count == 2) {
				c2 = Integer.parseInt(temp);
				change[index] = 0;
			}
			guesses--;
			guessed[index] = true;
		}
	}

	private void Card1ActionPerformed(java.awt.event.ActionEvent evt) {
		cardClicked(Card1);
	}

	private void Card2ActionPerformed(java.awt.event.ActionEvent evt) {
		cardClicked(Card2);
	}

	private void Card3ActionPerformed(java.awt.event.ActionEvent evt) {
		cardClicked(Card3);
	}

	private void Card4ActionPerformed(java.awt.event.ActionEvent evt) {
		cardClicked(Card4);
	}

	private void Card5ActionPerformed(java.awt.event.ActionEvent evt) {
		cardClicked(Card5);
	}

	private void Card6ActionPerformed(java.awt.event.ActionEvent evt) {
		cardClicked(Card6);
	}

	private void Card7ActionPerformed(java.awt.event.ActionEvent evt) {
		cardClicked(Card7);
	}

	private void Card8ActionPerformed(java.awt.event.ActionEvent evt) {
		cardClicked(Card8);
	}

	private void Card9ActionPerformed(java.awt.event.ActionEvent evt) {
		cardClicked(Card9);
	}

	private void Card10ActionPerformed(java.awt.event.ActionEvent evt) {
		cardClicked(Card10);
	}

	private void Card11ActionPerformed(java.awt.event.ActionEvent evt) {
		cardClicked(Card11);
	}

	private void Card12ActionPerformed(java.awt.event.ActionEvent evt) {
		cardClicked(Card12);
	}

	private void Card13ActionPerformed(java.awt.event.ActionEvent evt) {
		cardClicked(Card13);
	}

	private void Card14ActionPerformed(java.awt.event.ActionEvent evt) {
		cardClicked(Card14);
	}

	private void Card15ActionPerformed(java.awt.event.ActionEvent evt) {
		cardClicked(Card15);
	}

	private void Card16ActionPerformed(java.awt.event.ActionEvent evt) {
		cardClicked(Card16);
	}

	private void Card17ActionPerformed(java.awt.event.ActionEvent evt) {
		cardClicked(Card17);
	}

	private void Card18ActionPerformed(java.awt.event.ActionEvent evt) {
		cardClicked(Card18);
	}

	private void Card19ActionPerformed(java.awt.event.ActionEvent evt) {
		cardClicked(Card19);
	}

	private void Card20ActionPerformed(java.awt.event.ActionEvent evt) {
		cardClicked(Card20);
	}

	private void Card21ActionPerformed(java.awt.event.ActionEvent evt) {
		cardClicked(Card21);
	}

	private void Card22ActionPerformed(java.awt.event.ActionEvent evt) {
		cardClicked(Card22);
	}

	private void Card23ActionPerformed(java.awt.event.ActionEvent evt) {
		cardClicked(Card23);
	}

	private void Card24ActionPerformed(java.awt.event.ActionEvent evt) {
		cardClicked(Card24);
	}

	private void btuGuessAgainActionPerformed() {
		guesses = 2;
		count = 0;

		for (int i = 0; i < guessed.length; i++) {
			guessed[i] = false;
		}
		
		if (cardsLeft == 0) {
			txtInstruction.setText("Congratulations.");
		}

		// checking for matches
		if (c1 == c2) {
			for (int y = 1; y <= 2; y++) {
				if (change[0] == 0) {
					Card1.setIcon(done);
					change[0] = 2;
					matched[0] = true;
					cardsLeft--;
				} else if (change[1] == 0) {
					Card2.setIcon(done);
					change[1] = 2;
					matched[1] = true;
					cardsLeft--;
				} else if (change[2] == 0) {
					Card3.setIcon(done);
					change[2] = 2;
					matched[2] = true;
					cardsLeft--;
				} else if (change[3] == 0) {
					Card4.setIcon(done);
					change[3] = 2;
					matched[3] = true;
					cardsLeft--;
				} else if (change[4] == 0) {
					Card5.setIcon(done);
					change[4] = 2;
					matched[4] = true;
					cardsLeft--;
				} else if (change[5] == 0) {
					Card6.setIcon(done);
					change[5] = 2;
					matched[5] = true;
					cardsLeft--;
				} else if (change[6] == 0) {
					Card7.setIcon(done);
					change[6] = 2;
					matched[6] = true;
					cardsLeft--;
				} else if (change[7] == 0) {
					Card8.setIcon(done);
					change[7] = 2;
					matched[7] = true;
					cardsLeft--;
				} else if (change[8] == 0) {
					Card9.setIcon(done);
					change[8] = 2;
					matched[8] = true;
					cardsLeft--;
				} else if (change[9] == 0) {
					Card10.setIcon(done);
					change[9] = 2;
					matched[9] = true;
					cardsLeft--;
				} else if (change[10] == 0) {
					Card11.setIcon(done);
					change[10] = 2;
					matched[10] = true;
					cardsLeft--;
				} else if (change[11] == 0) {
					Card12.setIcon(done);
					change[11] = 2;
					matched[11] = true;
					cardsLeft--;
				} else if (change[12] == 0) {
					Card13.setIcon(done);
					change[12] = 2;
					matched[12] = true;
					cardsLeft--;
				} else if (change[13] == 0) {
					Card14.setIcon(done);
					change[13] = 2;
					matched[13] = true;
					cardsLeft--;
				} else if (change[14] == 0) {
					Card15.setIcon(done);
					change[14] = 2;
					matched[14] = true;
					cardsLeft--;
				} else if (change[15] == 0) {
					Card16.setIcon(done);
					change[15] = 2;
					matched[15] = true;
					cardsLeft--;
				} else if (change[16] == 0) {
					Card17.setIcon(done);
					change[16] = 2;
					matched[16] = true;
					cardsLeft--;
				} else if (change[17] == 0) {
					Card18.setIcon(done);
					change[17] = 2;
					matched[17] = true;
					cardsLeft--;
				} else if (change[18] == 0) {
					Card19.setIcon(done);
					change[18] = 2;
					matched[18] = true;
					cardsLeft--;
				} else if (change[19] == 0) {
					Card20.setIcon(done);
					change[19] = 2;
					matched[19] = true;
					cardsLeft--;
				} else if (change[20] == 0) {
					Card21.setIcon(done);
					change[20] = 2;
					matched[20] = true;
					cardsLeft--;
				} else if (change[21] == 0) {
					Card22.setIcon(done);
					change[21] = 2;
					matched[21] = true;
					cardsLeft--;
				} else if (change[22] == 0) {
					Card23.setIcon(done);
					change[22] = 2;
					matched[22] = true;
					cardsLeft--;
				} else if (change[23] == 0) {
					Card24.setIcon(done);
					change[23] = 2;
					matched[23] = true;
					cardsLeft--;
				}
			}
		} else {

			for (int z = 1; z <= 2; z++) {

				if (change[0] == 0) {
					Card1.setIcon(back);
					change[0] = 1;
				} else if (change[1] == 0) {
					Card2.setIcon(back);
					change[1] = 1;
				} else if (change[2] == 0) {
					Card3.setIcon(back);
					change[2] = 1;
				} else if (change[3] == 0) {
					Card4.setIcon(back);
					change[3] = 1;
				} else if (change[4] == 0) {
					Card5.setIcon(back);
					change[4] = 1;
				} else if (change[5] == 0) {
					Card6.setIcon(back);
					change[5] = 1;
				} else if (change[6] == 0) {
					Card7.setIcon(back);
					change[6] = 1;
				} else if (change[7] == 0) {
					Card8.setIcon(back);
					change[7] = 1;
				} else if (change[8] == 0) {
					Card9.setIcon(back);
					change[8] = 1;
				} else if (change[9] == 0) {
					Card10.setIcon(back);
					change[9] = 1;
				} else if (change[10] == 0) {
					Card11.setIcon(back);
					change[10] = 1;
				} else if (change[11] == 0) {
					Card12.setIcon(back);
					change[11] = 1;
				} else if (change[12] == 0) {
					Card13.setIcon(back);
					change[12] = 1;
				} else if (change[13] == 0) {
					Card14.setIcon(back);
					change[13] = 1;
				} else if (change[14] == 0) {
					Card15.setIcon(back);
					change[14] = 1;
				} else if (change[15] == 0) {
					Card16.setIcon(back);
					change[15] = 1;
				} else if (change[16] == 0) {
					Card17.setIcon(back);
					change[16] = 2;
				} else if (change[17] == 0) {
					Card18.setIcon(back);
					change[17] = 2;
				} else if (change[18] == 0) {
					Card19.setIcon(back);
					change[18] = 2;
				} else if (change[19] == 0) {
					Card20.setIcon(back);
					change[19] = 2;
				} else if (change[20] == 0) {
					Card21.setIcon(back);
					change[20] = 2;
				} else if (change[21] == 0) {
					Card22.setIcon(back);
					change[21] = 2;
				} else if (change[22] == 0) {
					Card23.setIcon(back);
					change[22] = 2;
				} else if (change[23] == 0) {
					Card24.setIcon(back);
					change[23] = 2;
				}
			}
		}
	}

	public static void main(String args[]) {
		try {
			for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
				if ("Nimbus".equals(info.getName())) {
					javax.swing.UIManager.setLookAndFeel(info.getClassName());
					break;
				}
			}
		} catch (ClassNotFoundException ex) {
			java.util.logging.Logger.getLogger(MatchingGame.class.getName()).log(java.util.logging.Level.SEVERE, null,
					ex);
		} catch (InstantiationException ex) {
			java.util.logging.Logger.getLogger(MatchingGame.class.getName()).log(java.util.logging.Level.SEVERE, null,
					ex);
		} catch (IllegalAccessException ex) {
			java.util.logging.Logger.getLogger(MatchingGame.class.getName()).log(java.util.logging.Level.SEVERE, null,
					ex);
		} catch (javax.swing.UnsupportedLookAndFeelException ex) {
			java.util.logging.Logger.getLogger(MatchingGame.class.getName()).log(java.util.logging.Level.SEVERE, null,
					ex);
		}

		/* Create and display the form */
		java.awt.EventQueue.invokeLater(new Runnable() {
			public void run() {
				new MatchingGame().setVisible(true);
			}
		});
	}

	private javax.swing.JButton Card1;
	private javax.swing.JButton Card10;
	private javax.swing.JButton Card11;
	private javax.swing.JButton Card12;
	private javax.swing.JButton Card13;
	private javax.swing.JButton Card14;
	private javax.swing.JButton Card15;
	private javax.swing.JButton Card16;
	private javax.swing.JButton Card2;
	private javax.swing.JButton Card3;
	private javax.swing.JButton Card4;
	private javax.swing.JButton Card5;
	private javax.swing.JButton Card6;
	private javax.swing.JButton Card7;
	private javax.swing.JButton Card8;
	private javax.swing.JButton Card9;
	private javax.swing.JLabel mainTitle;
	private javax.swing.JTextField txtInstruction;
	private JButton Card17;
	private JButton Card18;
	private JButton Card19;
	private JButton Card20;
	private JButton Card24;
	private JButton Card23;
	private JButton Card22;
	private JButton Card21;
	private JLabel label;
	private JLabel label_1;
	private JLabel label_2;
	private JLabel label_3;
	private JLabel label_4;
	private JLabel label_5;
	private JLabel label_6;
	private JLabel label_7;
	private JLabel label_8;
	private JLabel label_9;
}
